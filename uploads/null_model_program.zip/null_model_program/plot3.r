library(igraph)
#library(tcltk)


#set the path:
setwd("/Users/xiaokeeie/all_datasets/null_model_program")
rm(list=ls(all=TRUE))

#load the edges with time stamp
#there are three columns in edges: id1,id2,time
g1<-read.graph('BA_origin.txt', format = c("edgelist"),directed=FALSE)
g2<-read.graph('BA_assort.txt', format = c("edgelist"),directed=FALSE)
g3<-read.graph('BA_assortc.txt', format = c("edgelist"),directed=FALSE)
attach(mtcars)
opar<-par(no.readonly=TRUE)
par(fig=c(0,0.43,0,1))
plot(g1, layout=layout.fruchterman.reingold, 
     vertex.size=1, vertex.color="red", vertex.frame.color="red", vertex.label=NA, 
     edge.width = 0.5, edge.color = "green", edge.arrow.size=0.05, edge.arrow.width=0.5)

par(fig=c(0.30,0.73,0,1),new=TRUE)
plot(g2, layout=layout.fruchterman.reingold, 
     vertex.size=1, vertex.color="red", vertex.frame.color="red", vertex.label=NA, 
     edge.width = 0.5, edge.color = "green")

par(fig=c(0.57,1,0,1),new=TRUE)
plot(g3, layout=layout.fruchterman.reingold, 
     vertex.size=1, vertex.color="red", vertex.frame.color="red", vertex.label=NA, 
     edge.width = 0.5, edge.color = "green")
par(opar)
detach(mtcars)
